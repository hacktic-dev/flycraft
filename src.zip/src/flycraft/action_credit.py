"""Experimental action-conditioned steering on existing KC->MBON11 edges.

The anatomical left/right MBON11 cells are assigned game steering roles by us;
this is not a reconstructed biological motor-learning or dopamine circuit.
"""
import copy,math
import numpy as np

MODEL='action-conditioned-steering-v1'
DEFAULTS={'model':MODEL,'tau_ms':300.,'prediction_tau_ms':10000.,
          'reference_hz':50.,'max_yaw_deg_per_tick':6.,'eta':.02,
          'minimum_fraction':.5,'maximum_fraction':1.5,'max_log_update':.002}


def validate(c):
    if c.get('model')!=MODEL:raise ValueError('Unknown action-credit model')
    for k in DEFAULTS:
        if k=='model':continue
        if not math.isfinite(c[k]) or c[k]<=0:raise ValueError(f'Invalid action credit {k}')
    if not c['minimum_fraction']<1<c['maximum_fraction']:raise ValueError('Bounds must contain baseline')


def normalize(weights,baseline,lo,hi):
    """Keep each channel's baseline total synaptic weight, with hard bounds."""
    target=float(np.sum(baseline,dtype=np.float64))
    lower=baseline*lo;upper=baseline*hi
    left,right=0.,max(2.,float(np.max(upper/weights)))
    for _ in range(48):
        mid=(left+right)/2
        if np.clip(weights*mid,lower,upper).sum()<target:left=mid
        else:right=mid
    return np.clip(weights*((left+right)/2),lower,upper)


class ActionCredit:
    def __init__(self,brain,config):
        validate(config);self.b=brain;self.config=copy.deepcopy(config)
        cells=brain.circuit['report']['MBON']
        self.sides={s:next(x['index'] for x in cells if x['soma_side']==s) for s in ('L','R')}
        self.edges=brain.circuit['edges'];self.pre=brain.plastic_kc_index
        self.groups={s:np.flatnonzero(brain.post[self.edges]==i) for s,i in self.sides.items()}
        if any(not len(ix) for ix in self.groups.values()):raise ValueError('Both existing MBON channels required')
        for name,array in {
            'action_eligibility':np.zeros((2,len(brain.circuit['kc'])),np.float64),
            'action_expected':np.zeros(1,np.float64),'action_ready':np.zeros(1,np.int32),
            'action_last_rpe':np.zeros(1,np.float64),
        }.items():
            setattr(brain,name,array);brain.fields.append(name);brain.initial[name]=array.copy()
        original_signature=brain.configuration_signature
        brain.configuration_signature=lambda:{**original_signature(),'action_credit':self.config,'action_mbon_sides':self.sides}
        original_reset=brain.reset
        def reset(keep_memory=False):
            expected=brain.action_expected.copy()
            original_reset(keep_memory=keep_memory)
            if keep_memory:brain.action_expected[:]=expected
        brain.reset=reset
        # Disable the previous transient/fatigue rule and passive recovery in this
        # mode. Native stepping remains unchanged; teach() below is the only writer.
        brain.after_neural_bin=lambda counts,duration_ms,learning:None
        original_memory=brain.memory
        brain.memory=lambda:{**original_memory(),'model':MODEL,
            'expected_aim_improvement':float(brain.action_expected[0]),
            'last_rpe':float(brain.action_last_rpe[0])}

    def observe(self,counts,yaw_degrees,seconds=.05):
        if not math.isfinite(yaw_degrees) or not math.isfinite(seconds) or seconds<=0:raise ValueError('Invalid action interval')
        b=self.b;c=self.config
        if b.action_ready[0]:raise RuntimeError('Previous action has not received its outcome')
        decay=math.exp(-seconds*1000/c['tau_ms'])
        activity=np.clip(counts[b.circuit['kc']]/seconds/c['reference_hz'],0,1)
        amount=float(np.clip(yaw_degrees/c['max_yaw_deg_per_tick'],-1,1))
        b.action_eligibility*=decay
        b.action_eligibility[0]+=(1-decay)*activity*max(-amount,0)
        b.action_eligibility[1]+=(1-decay)*activity*max(amount,0)
        b.action_ready[0]=1

    def teach(self,improvement,seconds=.05):
        b=self.b;c=self.config
        if not math.isfinite(improvement) or not -1<=improvement<=1:raise ValueError('Bounded finite aim improvement required')
        if not b.action_ready[0]:raise RuntimeError('Record the action before its outcome')
        # A running expected-improvement baseline, not a state-conditioned critic.
        rpe=float(improvement-b.action_expected[0])
        b.action_expected[0]+=-math.expm1(-seconds*1000/c['prediction_tau_ms'])*rpe
        credit=b.action_eligibility[1]-b.action_eligibility[0]
        current=b.weight[self.edges].astype(np.float64)
        base=b.baseline_plastic.astype(np.float64)
        for side,indices in self.groups.items():
            direction=1 if side=='R' else -1
            delta=np.clip(c['eta']*rpe*credit[self.pre[indices]]*direction,-c['max_log_update'],c['max_log_update'])
            proposed=current[indices]*np.exp(delta)
            current[indices]=normalize(proposed,base[indices],c['minimum_fraction'],c['maximum_fraction'])
        b.weight[self.edges]=current.astype(b.weight.dtype)
        b.action_last_rpe[0]=rpe;b.action_ready[0]=0
        return {'signal':float(improvement),'rpe':rpe,'expected_improvement':float(b.action_expected[0]),
            'active_edges':int(np.count_nonzero(credit[self.pre])),
            'left_credit':float(b.action_eligibility[0].sum()),'right_credit':float(b.action_eligibility[1].sum())}
